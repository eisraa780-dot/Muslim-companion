# Muslim Companion — الرفيق المسلم

A bilingual (Arabic/English), lavender-themed progressive web app starter with:
- Responsive website layout
- Arabic/English language toggle
- Light/dark theme
- Offline caching (service worker)
- Local daily good-deed checklist
- Local tasbeeh counter
- Basic Islamic quiz
- Installable PWA prompt where supported
- Optional account approach (guest use is the default)

## Run locally
Because service workers require localhost or HTTPS, serve the `www` folder using a local web server. For example:
`python -m http.server 8000 --directory www`
Then open `http://localhost:8000`.

## Android packaging
This project includes a Capacitor configuration. To create an Android project after installing Node.js:
1. `npm install`
2. `npm run build`
3. `npx cap add android`
4. `npx cap sync android`
5. `npx cap open android`
6. In Android Studio, build a debug APK for testing or a signed release APK for distribution.

## Important unfinished integrations
This is a working starter/prototype, not a finished religious reference product:
- Prayer times currently show placeholders. Connect a reputable prayer-times calculation provider, ask for location permission only when needed, and let users choose calculation method and Asr method.
- Quran text, translations, audio and adhkar need to be populated from trusted, properly licensed sources and reviewed for accuracy.
- Android home-screen widgets require native Android widget implementation; the PWA itself does not create native widgets.
- Account registration/synchronization is not implemented. Guest data stays on the device. Add secure authentication and a privacy policy only if cloud accounts are introduced.
- Test accessibility, Arabic RTL layouts, offline behavior and device compatibility before publishing.

## Ethical / privacy defaults
No advertising, no social feed, no tracking SDK, and no account required in this starter.
